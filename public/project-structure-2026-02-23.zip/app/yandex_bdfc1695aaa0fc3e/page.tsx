export default function Page() {
  return (
    <html>
      <head>
        <meta httpEquiv="Content-Type" content="text/html; charset=UTF-8" />
      </head>
      <body>Verification: bdfc1695aaa0fc3e</body>
    </html>
  )
}
