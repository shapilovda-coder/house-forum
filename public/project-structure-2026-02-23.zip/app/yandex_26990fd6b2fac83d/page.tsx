export default function Page() {
  return (
    <html>
      <head>
        <meta httpEquiv="Content-Type" content="text/html; charset=UTF-8" />
      </head>
      <body>Verification: 26990fd6b2fac83d</body>
    </html>
  )
}
