export default function Page() {
  return (
    <html>
      <head>
        <meta httpEquiv="Content-Type" content="text/html; charset=UTF-8" />
      </head>
      <body>Verification: 0b44c9af9afed784</body>
    </html>
  )
}
